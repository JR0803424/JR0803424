const Discord = require('discord.js')
const client = new Discord.Client()

client.on('ready', () =>{
console.log('gago')
})

client.on('message', (message) => {
    console.log('$(message.author.tag}]: &{message.content}');
    if (message.content == '!ip') {
	message.reply('```𝗞𝗔𝗟𝗬𝗘 𝗕𝗘𝗡𝗧𝗘 𝗡𝗨𝗘𝗕𝗘: connect play.kalye29.com:30125')

    }
    else if (message.content == '!IP') {
    message.reply('```𝗞𝗔𝗟𝗬𝗘 𝗕𝗘𝗡𝗧𝗘 𝗡𝗨𝗘𝗕𝗘: connect play.kalye29.com:30125')
    } 
	
    else {
      
    }
	
})
client.login('ODA2ODU5NjY4MTQzMjEwNDk3.YBvknw.lCJZbe8Tt-3FXfuob6vGWrwYmDk')
