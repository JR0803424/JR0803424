const Discord = require('discord.js')
const client = new Discord.Client()

client.on('ready', () =>{
console.log('The bot has login.')
})

client.on('message', (message) => {
    console.log('$(message.author.tag}]: &{message.content}');
    if (message.content == '!ip') {
        message.reply('𝗞𝗔𝗟𝗬𝗘 𝗕𝗘𝗡𝗧𝗘 𝗡𝗨𝗘𝗩𝗘: connect play.kalye29.com:30125  /   𝗜𝗡𝗙𝗜𝗡𝗜𝗧𝗬 𝗥𝗣: CONNECT TRINITYRP.DDNS.NET')
    }
    else if (message.content == '!heaven') {
        message.reply('Cute ni 𝗛𝗲𝗮𝘃𝗲𝗻')
    } 
    else if (message.content == '!don primo') {
        message.reply('Babaero si 𝗗𝗼𝗻 𝗣𝗿𝗶𝗺𝗼')
    } 
    else if (message.content == '!miklo') {
        message.reply('Cute si 𝗠𝗶𝗸𝗹𝗼')
    } 
    else if (message.content == '!john vicks') {
        message.reply('Lagi nauuluhan ni heaven si 𝗝𝗼𝗵𝗻 𝗩𝗶𝗰𝗸𝘀')
    }
    else if (message.content == '!jomari') {
        message.reply('Pogi si 𝗝𝗼𝗺𝗮𝗿𝗶')
    } 
    else if (message.content == '!bonjo') {
        message.reply('𝗕𝗼𝗻𝗷𝗼 lang malakas')
    }
	else if (message.content == '!k29') {
        message.reply('𝗞𝗔𝗟𝗬𝗘 𝗕𝗘𝗡𝗧𝗘 𝗡𝗨𝗘𝗩𝗘 LANG MALAKAS!')
    }  else {
        
    }
    
})

client.login('ODA2ODU5NjY4MTQzMjEwNDk3.YBvknw.0ZxghVXUJoCyZulh_S2PLmxdXZs')